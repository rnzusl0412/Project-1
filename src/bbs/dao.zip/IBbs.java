package bbs.dao;

/*
 *  CREATE TABLE BBS (
 	BBS_NO NUMBER(20), 
 	BBS_TIT VARCHAR2(100), 
 	BBS_USER VARCHAR2(30), 
 	BBS_DATE DATE, 
 	BBS_CON VARCHAR2(2000), 
 	BBS_UP NUMBER(10), 
 	BBS_DO NUMBER(10)
 	);
 * 
 */

public interface IBbs {

	String insert_bbs = "insert into bbs values(BBSNO.NEXTVAL,?,?,?,sysdate,?,?,?,?)";
	
	String all_bbs = "select * from bbs";
	String all_bbs_re = "select * from bbs a left outer join re b on a.bbs_no = b.re_bno";
	
	String select_bbs = "select * from bbs a left outer join re b on a.bbs_no = b.re_bno where a.bbs_user like '%?%'";
	String select_bbs01 = "select * from bbs a left outer join re b on a.bbs_no = b.re_bno where a.bbs_tit like '%?%'";
	String select_bbs02 = "select * from bbs a left outer join re b on a.bbs_no = b.re_bno where a.bbs_con like '%?%'";
	String select_bbs03 = "select * from bbs a left outer join re b on a.bbs_no = b.re_bno where a.bbs_tit like '%?%' or a.bbs_con like '%?%'";
	
	String update_bbs = "update bbs set bbs_tit = ?, bbs_con =?, bbs_file = ?, bbs_fp = ? where bbs_no = ? and bbs_user = ?";		//제목 내용
	
	String delete_bbs = "delete bbs where bbs_no = ?";
	String delete_bbs01 = "delete bbs where bbs_user = ?";
	
	
	/*String delete_bbs = "delete from bbs where name=?";
	String find_bbs = "select * from myscore where name=?";
	String update_bbs = "update bbs set kor=?, mat=?, eng=?,tot=?,avg=?,grade=? where name = ?";
	String select_bbs = "select * from bbs";
	*/
}
